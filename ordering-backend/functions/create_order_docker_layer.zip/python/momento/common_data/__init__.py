"""Package for common data between request and response types."""
