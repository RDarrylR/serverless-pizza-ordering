from enum import Enum


class SortOrder(Enum):
    ASCENDING = True
    DESCENDING = False
