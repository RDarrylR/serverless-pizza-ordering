from .credential_provider import CredentialProvider

__all__ = ["CredentialProvider"]
